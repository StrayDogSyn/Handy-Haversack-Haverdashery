# Quick Reference - Handy Haversack Haverdashery

## 🚀 First Time Setup

**Windows:**
```bash
setup-windows.bat
```

**Mac/Linux:**
```bash
chmod +x setup-unix.sh
./setup-unix.sh
```

## 🎮 Daily Development

### Start Backend (Terminal 1)
```bash
cd backend
source venv/bin/activate    # Mac/Linux
# OR
venv\Scripts\activate       # Windows

uvicorn app.main:app --reload
```
→ API at http://localhost:8000
→ Docs at http://localhost:8000/docs

### Start Frontend (Terminal 2)
```bash
cd frontend
npm start
```
→ App at http://localhost:3000

## 📝 Common Tasks

### Add a New API Endpoint
1. Edit/create file in `backend/app/api/`
2. Add router functions
3. Include router in `backend/app/main.py`
4. Test at http://localhost:8000/docs

### Add a New React Component
1. Create `.tsx` file in `frontend/src/components/`
2. Import component in `App.tsx`
3. View at http://localhost:3000

### Update Database Model
1. Edit `backend/app/models/character.py`
2. Delete `data/sqlite/pathfinder.db`
3. Restart backend (recreates database)

## 🧪 Testing

### Test Dice Roller
```bash
cd backend
pytest tests/test_dice.py
# OR run the file directly:
python tests/test_dice.py
```

### Test API Manually
1. Go to http://localhost:8000/docs
2. Click any endpoint
3. Click "Try it out"
4. Enter test data and "Execute"

## 📦 Git Workflow

### Start New Feature
```bash
git checkout -b feature/your-feature-name
# Make changes...
git add .
git commit -m "Add: description of feature"
git push origin feature/your-feature-name
```

### Update from Main
```bash
git checkout main
git pull origin main
git checkout feature/your-feature-name
git merge main
```

## 🔧 Troubleshooting

### Port Already in Use
```bash
# Backend - use different port
uvicorn app.main:app --reload --port 8001

# Frontend - create .env file
echo "PORT=3001" > frontend/.env
```

### Python Module Not Found
```bash
# Make sure venv is activated!
cd backend
source venv/bin/activate    # Mac/Linux
venv\Scripts\activate       # Windows
pip install -r requirements.txt
```

### Database Errors
```bash
# Reset database
rm data/sqlite/pathfinder.db
# Restart backend - it will recreate
```

### CORS Errors
1. Make sure backend is running
2. Check frontend is calling http://localhost:8000
3. Verify `backend/.env` has correct CORS settings

## 🎲 API Quick Tests

### Roll Dice
```bash
curl -X POST "http://localhost:8000/api/dice/roll" \
  -H "Content-Type: application/json" \
  -d '{"expression": "1d20+5", "advantage": false}'
```

### Create Character
```bash
curl -X POST "http://localhost:8000/api/characters/" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Valeros",
    "class": "Fighter",
    "level": 5,
    "strength": 18,
    "dexterity": 14,
    "constitution": 16,
    "intelligence": 10,
    "wisdom": 12,
    "charisma": 8,
    "hit_points_max": 52,
    "hit_points_current": 52,
    "armor_class": 19
  }'
```

### Generate Encounter
```bash
curl -X POST "http://localhost:8000/api/encounters/generate" \
  -H "Content-Type: application/json" \
  -d '{
    "party_level": 5,
    "party_size": 4,
    "difficulty": "moderate"
  }'
```

## 📚 File Locations

```
Project Root/
├── backend/app/
│   ├── api/              → API endpoints
│   ├── models/           → Database models
│   ├── services/         → Business logic
│   └── main.py           → FastAPI app
├── frontend/src/
│   └── components/       → React components
├── data/
│   ├── pdfs/            → Your Pathfinder PDFs
│   └── sqlite/          → Database (auto-created)
└── docs/                → Documentation
```

## 🎯 Feature Priority

**Phase 1 (MVP - Done!):**
- ✅ Dice roller
- ✅ Character CRUD
- ✅ Encounter generator

**Phase 2 (Next up):**
- [ ] Character sheet UI
- [ ] Initiative tracker
- [ ] Expand bestiary

**Phase 3 (Future):**
- [ ] PDF parsing
- [ ] Spell database
- [ ] Campaign notes

## 💡 Development Tips

1. **Test backend first** before building frontend
2. **Use the API docs** at /docs - they're interactive!
3. **Commit often** with clear messages
4. **One feature at a time** - complete before moving on
5. **Check both terminals** if something breaks

## 🆘 Get Help

- **API not responding?** Check Terminal 1 for errors
- **Frontend blank?** Check Terminal 2 and browser console
- **Changes not showing?** Hard refresh: Ctrl+Shift+R (Cmd+Shift+R on Mac)
- **Git conflicts?** Ask before forcing anything

---

**Remember:** Backend = http://localhost:8000, Frontend = http://localhost:3000

May your rolls be natural 20s! 🎲
